﻿-- HE172481 - Phan Tiến Mạnh
CREATE DATABASE Lab4;



