﻿-- Create the Departments table
use Lab4;
CREATE TABLE Departments (
  DeptID VARCHAR(4) PRIMARY KEY,
  Name NVARCHAR(50) NOT NULL,
  NoOfStudents INT
);

-- Create the Students table
CREATE TABLE Students (
  StudentID VARCHAR(4) PRIMARY KEY,
  LastName NVARCHAR(10),
  FirstName NVARCHAR(30),
  Sex VARCHAR(1) CHECK (Sex IN ('F', 'M')),
  DateOfBirth DATE,
  PlaceOfBirth NVARCHAR(30),
  DeptID VARCHAR(4),
  Scholarship FLOAT,
  AverageScore NUMERIC(4, 2),
  CONSTRAINT FK_DeptID FOREIGN KEY (DeptID) REFERENCES Departments (DeptID)
);

-- Create the Courses table
CREATE TABLE Courses (
  CourseID VARCHAR(4) PRIMARY KEY,
  Name NVARCHAR(35),
  Credits TINYINT
);

-- Create the Results table
CREATE TABLE Results (
  StudentID VARCHAR(4),
  CourseID VARCHAR(4),
  Year INT,
  Semester INT,
  Mark FLOAT(1),
  Grade VARCHAR(6) ,
  PRIMARY KEY (StudentID, CourseID,year,semester),
  CONSTRAINT FK_StudentID FOREIGN KEY (StudentID) REFERENCES Students (StudentID),
  CONSTRAINT FK_CourseID FOREIGN KEY (CourseID) REFERENCES Courses (CourseID)
);


-- Insert data into the Departments table
INSERT INTO Departments (DeptID, Name, NoOfStudents)
VALUES
  ('IS', 'Information Systems', NULL),
  ('NC', 'Network and Communication', NULL),
  ('SE', 'Software Engineering', NULL),
  ('CE', 'Computer Engineering', NULL),
  ('CS', 'Computer Science', NULL);

-- Insert data into the Students table
INSERT INTO Students (StudentID, LastName, FirstName, Sex, DateOfBirth, PlaceOfBirth, DeptID, Scholarship, AverageScore)
VALUES
  ('S001', 'Lê', 'Kim Lan', 'F', '1990-02-23', 'Hà nội', 'IS', 130000, NULL),
  ('S002', 'Trần', 'Minh Chánh', 'M', '1992-12-24', 'Bình Định', 'NC', 150000, NULL),
  ('S003', 'Lê', 'An Tuyết', 'F', '1991-02-21', 'Hải phòng', 'IS', 170000, NULL),
  ('S004', 'Trần', 'Anh Tuấn', 'M', '1993-12-20', 'TpHCM', 'NC', 80000, NULL),
  ('S005', 'Trần', 'Thị Mai', 'F', '1991-08-12', 'TpHCM', 'SE', 0, NULL),
  ('S006', 'Lê', 'Thị Thu Thủy', 'F', '1991-01-02', 'An Giang', 'IS', 0, NULL),
  ('S007', 'Nguyễn', 'Kim Thư', 'F', '1990-02-02', 'Hà Nội', 'SE', 180000, NULL),
  ('S008', 'Lê', 'Văn Long', 'M', '1992-12-08', 'TpHCM', 'IS', 190000, NULL);

-- Insert data into the Courses table
INSERT INTO Courses (CourseID, Name, Credits)
VALUES
  ('DS01', 'Database Systems', 3),
  ('AI01', 'Artificial Intelligence', 3),
  ('CN01', 'Computer Network', 3),
  ('CG01', 'Computer Graphics', 4),
  ('DSA1', 'Data Structures and Algorithms', 4);

-- Insert data into the Results table
INSERT INTO Results (StudentID, CourseID, Year, Semester, Mark, Grade)
VALUES
  ('S001', 'DS01', 2017, 1, 3, NULL),
  ('S001', 'DS01', 2017, 2, 6, NULL),
  ('S001', 'AI01', 2017, 1, 4.5, NULL),
  ('S001', 'AI01', 2017, 2, 6, NULL),
  ('S001', 'CN01', 2017, 3, 5, NULL),
  ('S002', 'DS01', 2016, 1, 4.5, NULL),
  ('S002', 'DS01', 2017, 1, 7, NULL),
  ('S002', 'CN01', 2016, 3, 10, NULL),
  ('S002', 'DSA1', 2016, 3, 9, NULL),
  ('S003', 'DS01', 2017, 1, 2, NULL),
  ('S003', 'DS01', 2017, 3, 5, NULL),
  ('S003', 'CN01', 2017, 2, 2.5, NULL),
  ('S003', 'CN01', 2017, 3, 4, NULL),
  ('S004', 'DS01', 2017, 3, 4.5, NULL),
  ('S004', 'DSA1', 2018, 1, 10, NULL),
  ('S005', 'DS01', 2017, 2, 7, NULL),
  ('S005', 'CN01', 2017, 2, 2.5, NULL),
  ('S005', 'CN01', 2018, 1, 5, NULL),
  ('S006', 'AI01', 2018, 1, 6, NULL),
  ('S006', 'CN01', 2018, 2, 10, NULL);