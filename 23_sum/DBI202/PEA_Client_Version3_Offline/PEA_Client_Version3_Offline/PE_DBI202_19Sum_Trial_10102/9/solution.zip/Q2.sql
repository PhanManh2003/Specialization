
select * from dbo.Customer where Segment ='Consumer' and city = 'Arlington'