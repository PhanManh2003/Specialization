
function App() {
  return (
    <div>
      Practical Exam - FER202
    </div>
  );
}

export default App;
