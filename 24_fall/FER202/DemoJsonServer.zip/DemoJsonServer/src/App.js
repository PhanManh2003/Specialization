import React, { useEffect, useState } from "react";

import InformationDisclosure from "./InformationDisclosure";
import ListOfInformation from "./ListOfInformation";

const App = () => {
  const [dat, setData] = useState([]);

  const callFetchApi = async () => {
    try {
      const response = await fetch("http://localhost:3000/data");
      if (!response.ok) {
        throw new Error(`Response status: ${response.status}`);
      }

      const json = await response.json();
      setData(json);
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    callFetchApi();
  }, []);

  const addFunc = (name, date, tech, courses) => {
    const [year, month, day] = date.split("-");
    setData((prev) => [
      ...prev,
      {
        name: name,
        dob: `${day}/${month}/${year}`,
        courses: courses.map((course) => ({
          name: course,
        })),
        qualities: tech,
      },
    ]);
  };

  const searchFunc = (name) => {
    if (!!name) {
      let newData;
      newData = [...dat.filter((item) => item?.name?.toLowerCase()?.includes(name?.toLowerCase()))];
      setData(newData);
    } else {
      callFetchApi();
    }
  };

  return (
    <div className="container my-5">
      <InformationDisclosure addFunc={addFunc} searchFunc={searchFunc} />
      <ListOfInformation data={dat ?? []} />
    </div>
  );
};

export default App;
