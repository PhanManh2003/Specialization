const qualities = ["Very good", "Good", "Nordgdsmal", "Bad"];
export default qualities;
