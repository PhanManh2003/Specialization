const data = [
  {
    id: 1,
    name: "John Doe",
    dob: "25/05/2000",
    courses: [
      { id: "1", name: "Java" },
      { id: "2", name: "English" },
    ],
    qualities: "Very good",
  },
  {
    id: 2,
    name: "Jane Smith",
    dob: "12/04/1999",
    courses: [{ id: "3", name: "Japanese" }],
    qualities: "Bad",
  },
  {
    id: 2,
    name: "Mary Monroe",
    dob: "01/09/1995",
    courses: [
      { id: "3", name: "Japanese" },
      { id: "2", name: "English" },
    ],
    qualities: "Normal",
  },
];
export default data;
