const qualities = ["Very good", "Good", "Normal", "Bad"];
export default qualities;
