import React, { useEffect, useState } from "react";
import axios from 'axios'; // Import Axios
import InformationDisclosure from "./InformationDisclosure";
import ListOfInformation from "./ListOfInformation";

const App = () => {
  const [dat, setData] = useState([]);
  const [qualities, setQualities] = useState([]);
  const [courses, setCourses] = useState([]);
  const [originalData, setOriginalData] = useState([]);

  const callFetchApi = async () => {
    try {
      // Fetching teachers' data
      const response = await axios.get("http://localhost:9000/teachers");
      const json = response.data;
  
      // Initialize an array to hold teachers with details
      const teachersWithDetails = [];
  
      // Loop through each teacher to fetch their details
      for (const teacher of json) {
        // Fetching courses associated with the current teacher
        const teacherCoursesResponse = await axios.get(`http://localhost:9000/teachers_courses?teacherId=${teacher.id}`);
        const teacherCourses = teacherCoursesResponse.data;
  
        // Initialize an array to hold course details
        const coursesDetails = [];
        
        // Fetch course details based on course ID one by one
        for (const course of teacherCourses) {
          const courseResponse = await axios.get(`http://localhost:9000/courses/${course.courseId}`);
          coursesDetails.push(courseResponse.data);
        }
  
        // Fetching qualities associated with the current teacher
        const teacherQualitiesResponse = await axios.get(`http://localhost:9000/teachers_qualities?teacherId=${teacher.id}`);
        const teacherQualities = teacherQualitiesResponse.data;
  
        // Initialize an array to hold quality details
        const qualitiesDetails = [];
  
        // Fetch quality details based on quality ID one by one
        for (const quality of teacherQualities) {
          const qualityResponse = await axios.get(`http://localhost:9000/qualities/${quality.qualityId}`);
          qualitiesDetails.push(qualityResponse.data);
        }
  
        // Returning teacher object with courses and qualities attached
        teachersWithDetails.push({
          ...teacher,
          courses: coursesDetails,
          qualities: qualitiesDetails.map(q => q.name).join(", ") // Combine all qualities into a single string
        });
      }
  
      // Updating state with teacher details
      setData(teachersWithDetails);
      setOriginalData(teachersWithDetails);
    } catch (error) {
      console.error(error.message); // Log error if fetch fails
    }
  };

  useEffect(() => {
    callFetchApi();
  }, []);

  useEffect(() => {
    const fetchQualities = async () => {
      try {
        const response = await axios.get("http://localhost:9000/qualities");
        setQualities(response.data);
      } catch (error) {
        console.error(error.message);
      }
    };

    fetchQualities();
  }, []);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await axios.get("http://localhost:9000/courses");
        setCourses(response.data);
      } catch (error) {
        console.error(error.message);
      }
    };

    fetchCourses();
  }, []);

  return (
    <div className="container my-5">
      <InformationDisclosure addFunc={addFunc} searchFunc={searchFunc} qualities={qualities} courses={courses} />
      <ListOfInformation data={dat ?? []} />
    </div>
  );
};

export default App;
