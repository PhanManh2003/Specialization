const qualities = [
    { id: "1", name: "Very good" },
    { id: "2", name: "Good" },
    { id: "3", name: "Normal" },
    { id: "4", name: "Bad" },
  ];
  
  export default qualities;
  