import React, { useEffect, useState } from "react";
import axios from 'axios'; // Import Axios
import InformationDisclosure from "./InformationDisclosure";
import ListOfInformation from "./ListOfInformation";

const App = () => {
  const [dat, setData] = useState([]);
  const [qualities, setQualities] = useState([]);
  const [courses, setCourses] = useState([]);

  const callFetchApi = async () => {
    try {
      const response = await axios.get("http://localhost:9000/teachers");
      const json = response.data;

      const teachersWithDetails = await Promise.all(
        json.map(async (teacher) => {
          const teacherCoursesResponse = await axios.get(`http://localhost:9000/teachers_courses?teacherId=${teacher.id}`);
          const teacherCourses = teacherCoursesResponse.data;

          const coursesDetails = await Promise.all(
            teacherCourses.map(async (course) => {
              const courseResponse = await axios.get(`http://localhost:9000/courses/${course.courseId}`);
              return courseResponse.data;
            })
          );

          const teacherQualitiesResponse = await axios.get(`http://localhost:9000/teachers_qualities?teacherId=${teacher.id}`);
          const teacherQualities = teacherQualitiesResponse.data;

          const qualitiesDetails = await Promise.all(
            teacherQualities.map(async (quality) => {
              const qualityResponse = await axios.get(`http://localhost:9000/qualities/${quality.qualityId}`);
              return qualityResponse.data;
            })
          );

          return {
            ...teacher,
            courses: coursesDetails,
            qualities: qualitiesDetails.map(q => q.name).join(", ")
          };
        })
      );

      setData(teachersWithDetails);
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    callFetchApi();
  }, []);

  useEffect(() => {
    const fetchQualities = async () => {
      try {
        const response = await axios.get("http://localhost:9000/qualities");
        setQualities(response.data);
      } catch (error) {
        console.error(error.message);
      }
    };

    fetchQualities();
  }, []);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await axios.get("http://localhost:9000/courses");
        setCourses(response.data);
      } catch (error) {
        console.error(error.message);
      }
    };

    fetchCourses();
  }, []);

  const addFunc = async (name, date, tech, courses) => {
    const [year, month, day] = date.split("-");
    // Lấy ID lớn nhất hiện có
    const teachersResponse = await axios.get("http://localhost:9000/teachers");
    const teachersData = teachersResponse.data;
    const newId = teachersData.length ? Math.max(...teachersData.map(t => t.id)) + 1 : 1;
    const newTeacher = {
      id: newId,  // Sử dụng ID tự quản lý
      name: name,
      dob: `${day}/${month}/${year}`,
    };
    try {
      const teacherResponse = await axios.post("http://localhost:9000/teachers", newTeacher);
      if (teacherResponse.status === 201) {
        const teacherId = teacherResponse.data.id;
        await Promise.all(
          courses.map(async (courseName) => {
            const courseResponse = await axios.get(`http://localhost:9000/courses?name=${courseName}`);
            const courseId = courseResponse.data[0]?.id;
            if (courseId) {
              await axios.post("http://localhost:9000/teachers_courses", {
                teacherId: teacherId,
                courseId: courseId,
              });
            }
          })
        );

        const qualityResponse = await axios.get(`http://localhost:9000/qualities?name=${tech}`);
        const qualityId = qualityResponse.data[0]?.id;

        if (qualityId) {
          await axios.post("http://localhost:9000/teachers_qualities", {
            teacherId: teacherId,
            qualityId: qualityId,
          });
        }

        callFetchApi(); // Tải lại dữ liệu sau khi thêm
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  const searchFunc = async (name) => {
    if (!!name) {
      const response = await axios.get(`http://localhost:9000/teachers?name_like=${name}`);
      setData(response.data);
    } else {
      callFetchApi();
    }
  };

  return (
    <div className="container my-5">
      <InformationDisclosure addFunc={addFunc} searchFunc={searchFunc} qualities={qualities} courses={courses} />
      <ListOfInformation data={dat ?? []} />
    </div>
  );
};

export default App;
